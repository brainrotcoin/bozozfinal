<header>
    <div class="logo-container">
        <img src="assets/images/logo.png" alt="SolanaBozos Logo" class="logo">
    </div>
    <button class="hamburger">
        <i class="fas fa-bars"></i>
    </button>
    <nav class="neon-nav">
        <a href="#" data-section="home">Home</a>
        <a href="#" data-section="games">Games</a>
        <a href="#" data-section="meme_contest">Meme Contest</a>
        <a href="#" data-section="nft">NFT</a>
        <a href="#" data-section="about">About</a>
        <a href="#" data-section="roadmap">Roadmap</a>
        <a href="#" data-section="tokenomics">Tokenomics</a>
        <a href="#" data-section="buy">Buy</a>
    </nav>
</header>