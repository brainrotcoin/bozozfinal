<footer class="neon-footer">
    <div class="footer-content">
        <div class="footer-left">
            <p class="glow-text">🃏 Join the Bozo Revolution 🎪</p>
            <div class="footer-social">
                <a href="https://x.com/thesolanabozos" target="_blank" class="social-icon">
                    <i class="fab fa-twitter"></i>
                </a>
                <a href="https://t.me/solanabozosofficial" target="_blank" class="social-icon">
                    <i class="fab fa-telegram"></i>
                </a>
                <a href="https://dexscreener.com/solana/YourContractAddress" target="_blank" class="social-icon">
                    <i class="fas fa-chart-line"></i>
                </a>
            </div>
        </div>
        <div class="footer-right">
            <p class="footer-copyright">🔮 <?php echo date('Y'); ?> SolanaBozos. All rights <span class="glitch-text">degenerated</span> 🔮</p>
        </div>
    </div>
</footer>