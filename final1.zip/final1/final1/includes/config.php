<?php
define("SITE_NAME", "SolanaBozos");
define("SITE_URL", "https://solanabozos.com"); // Update with your domain
?>