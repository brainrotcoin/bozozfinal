<?php
$contract = "YourContractAddressHere"; // Replace with actual address
echo "<p class='neon-text'>Contract Address: " . htmlspecialchars($contract) . "</p>";
?>