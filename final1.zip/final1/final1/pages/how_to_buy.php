<!-- how_to_buy.php - How to Buy Section -->
<section id="how_to_buy">
    <h1 class="glitch-text">How to Buy $BOZO</h1>
    <p>Step 1: Open Pump.fun and search for SolanaBozos.<br>
       Step 2: Ape in with SOL.<br>
       Step 3: Hodl and meme away!</p>
    <img src="assets/images/section_how_to_buy.png" alt="Bozo How to Buy" class="floating">
</section>