<section id="home" class="neon-section">
    <!-- Add this to your home.php section -->
<div class="home-social-links">
    <a href="https://x.com/thesolanabozos" target="_blank" class="social-icon">
        <i class="fab fa-twitter"></i>
    </a>
    <a href="https://t.me/solanabozosofficial" target="_blank" class="social-icon">
        <i class="fab fa-telegram"></i>
    </a>
    <a href="https://dexscreener.com/solana/YourContractAddress" target="_blank" class="social-icon">
        <i class="fas fa-chart-line"></i>
    </a>
</div>
    <div class="home-content">
        <div class="home-text">
            <h1 class="glitch-text">Welcome to the BozoVerse – The Wildest Meme Coin on Solana! 🤡💀</h1>
            <p class="neon-text">
                🚀 No Utility. No Roadmap. Just Pure Degen Chaos. 🚀
            </p>
            <p class="neon-text">
                Welcome to Solana Bozos ($BOZO)—the ultimate meme coin for true degenerates! If you’re here for utility, fundamentals, or serious investing, you’re in the wrong place. We don’t plan, we just ape. This is a community-powered meme experiment where clownery meets crypto insanity.
            </p>
            <p class="neon-text">
                🔹 What is Solana Bozos?<br>
                It’s simple: Bozos don’t plan, we ape. 💀 No taxes, no team allocations, no useless promises. Just 100% pure degen energy, memes, and mayhem. Built on Solana, made for the biggest clowns in crypto.
            </p>
            <p class="neon-text">
                💀 If you don’t get it, you’re NGMI.
            </p>
        </div>
        <div class="home-image">
            <img src="assets/images/animation.gif" alt="Bozo About" class="neon-frame floating">
        </div>
    </div>
</section>