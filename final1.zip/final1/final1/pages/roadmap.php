<section id="roadmap" class="neon-section">
    <div class="roadmap-content">
        <div class="roadmap-text">
            <h1 class="glitch-text">🗺️ The Only Real Meme Token Roadmap – No BS, Just Bozo Energy 🤡💀</h1>
            <p class="neon-text">
                🚨 Anyone who tells you they have a "serious roadmap" for a meme coin is just shitposting.<br>
                Meme tokens are about fun, degeneracy, and absolute chaos. High risk, high reward. That’s the game. 🎪
            </p>
            
            <h2 class="glitch-text">📢 Step 1: Spread the Bozo Gospel 🚀</h2>
            <ul class="neon-text">
                <li>✅ Get $BOZO listed on as many exchanges as possible – Because the more Bozos we have, the bigger the circus.</li>
                <li>✅ Expand the community – More memes, more degeneracy, more FOMO.</li>
            </ul>

            <h2 class="glitch-text">🛍️ Step 2: Merch Store – Drip Like a True Bozo 🎭</h2>
            <p class="neon-text">
                Yes, we’re planning an official Solana Bozos merch store for all degens & fans.<br>
                🎽 T-shirts, hoodies, stickers, and more – Because repping $BOZO IRL is a flex.
            </p>

            <h2 class="glitch-text">🎨 Step 3: NFTs? Maybe… Maybe Not. 🤔</h2>
            <ul class="neon-text">
                <li>💀 NFTs in meme coins are a big question mark.</li>
                <li>📢 This will be decided by the community. No forced roadmaps, no fake hype.</li>
                <li>If the Bozo army wants it, we’ll make it happen. If not, we keep clowning.</li>
            </ul>

            <h2 class="glitch-text">🎮 Step 4: Wallet Integration for Bozo Games 🕹️</h2>
            <p class="neon-text">
                Right now, you play games for fun. But soon…<br>
                ✅ Wallet integration with game points<br>
                ✅ Earn points & actually use them for something (TBD)<br>
                ✅ More degeneracy, more rewards, more chaos<br>
                <em>This isn’t play-to-earn. This is play-to-clown. 🤡💥</em>
            </p>

            <h2 class="glitch-text">🗳️ Step 5: Community Votes – No DAO, No BS 🎪</h2>
            <p class="neon-text">
                Every major decision will be made by the community.<br>
                No centralized control, no empty promises—just raw degen energy.<br>
                📢 We don’t need a DAO to decide things. We’ll just vote and send it.
            </p>

            <h2 class="glitch-text">🚀 Final Words: No Promises, Just Bozo Mayhem</h2>
            <p class="neon-text">
                We’re not here to overpromise. We’re here to embrace the meme, have fun, and send it.<br>
                You either get it, or you don’t. 🤡💀
            </p>
            <p class="neon-text">
                📢 Follow, Ape In, and Be Part of the Madness. 🚀
            </p>
        </div>
        
        <div class="roadmap-image">
            <img src="assets/images/mascot.png" alt="Bozo Mascot" class="neon-frame floating">
        </div>
    </div>
</section>